package com.epam.sum_university.properties;

public final class Properties {
    public static final String LOGIN = "alyashelya@gmail.com";
    public static final String PASS = "fEhCJixR65FrTDe!";
    public static final String LOGIN1 = "alyashelya+dz@gmail.com";
    public static final String PASS1 = "Qa2810*test";
    public static final String EMAIL = "alina.tester2021@gmail.com";
    public static final String NAME = "Alina";
    public static final String LAST_NAME = "Shelest";
    public static final String POST_TITLE = "TITLE";
    public static final String POST_DESC = "description";
    public static final String COMMENT = "comment";
    public static final String ADDRESS = "jefkdsj 43k";
    public static final String WEBSITE = "https://fskfl";
    public static final String BIRTHDAY = "26.02.2001";
    public static final String INV_EMAIL = "alina.tester2021gmail.com";
    public static final String EMAIL_PASS = "alina.tester2021@gmail.com";

}
