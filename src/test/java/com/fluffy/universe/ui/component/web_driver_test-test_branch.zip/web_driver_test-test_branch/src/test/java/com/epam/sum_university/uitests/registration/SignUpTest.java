package com.epam.sum_university.uitests.registration;

import com.epam.sum_university.BaseTest;
import com.epam.sum_university.pageobject.pages.HomePage;
import com.epam.sum_university.pageobject.pages.SignInPage;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import java.io.IOException;

import static com.epam.sum_university.properties.Properties.*;

public class SignUpTest extends BaseTest {

    @AfterTest
    public void tearDown() {
        quit();
    }

    @Test
    public void positiveSignInTest() throws IOException {
        SignInPage signInPage = new SignInPage(webDriver);
        Boolean flag;
        HomePage loggedUser = signInPage
                .open()
                .signIn(NAME, LAST_NAME
                        , LOGIN1, PASS, PASS);
        loggedUser.capture("sign-up/positive");
        flag=loggedUser.verifyLogin();
        Assert.assertTrue(flag);
    }
}
