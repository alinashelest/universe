package com.epam.sum_university.uitests.login;

import com.epam.sum_university.BaseTest;
import com.epam.sum_university.pageobject.pages.LoginPage;
import org.apache.commons.logging.Log;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import java.io.IOException;

import static com.epam.sum_university.properties.Properties.LOGIN1;

public class LoginWithEmptyPassword extends BaseTest {

    @AfterTest
    public void tearDown() {
        quit();
    }

    @Test
    public void LoginWithEmptyPassword() throws IOException {
        LoginPage loginPage = new LoginPage(webDriver);
        boolean flag;
        LoginPage errorLogin = loginPage
                .open()
                .negLoginEmptyPassword(LOGIN1);
        errorLogin.capture("login/negative");
        flag = errorLogin.existErrorLoginEmptyPassword();

        Assert.assertTrue(flag);
    }
}
