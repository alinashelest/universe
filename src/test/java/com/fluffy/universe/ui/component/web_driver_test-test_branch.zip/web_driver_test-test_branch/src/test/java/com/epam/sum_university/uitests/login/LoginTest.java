package com.epam.sum_university.uitests.login;

import com.epam.sum_university.BaseTest;
import com.epam.sum_university.pageobject.pages.HomePage;
import com.epam.sum_university.pageobject.pages.LoginPage;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import java.io.IOException;

import static com.epam.sum_university.properties.Properties.LOGIN;
import static com.epam.sum_university.properties.Properties.PASS;

public class LoginTest extends BaseTest {

    @AfterTest
    public void tearDown() {
        quit();
    }

    @Test
    public void positiveLoginTest() throws IOException {
        LoginPage loginPage = new LoginPage(webDriver);
        Boolean flag;
        HomePage userInformation = loginPage
                .open()
                .login(LOGIN, PASS);
        userInformation.capture("login/positive");
        flag = userInformation.verifyLogin();
        Assert.assertTrue(flag);
    }
}
