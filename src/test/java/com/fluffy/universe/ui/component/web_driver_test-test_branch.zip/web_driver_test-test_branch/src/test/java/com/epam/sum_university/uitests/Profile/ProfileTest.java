package com.epam.sum_university.uitests.post;

import com.epam.sum_university.BaseTest;
import com.epam.sum_university.pageobject.pages.AccountPage;
import com.epam.sum_university.pageobject.pages.LoginPage;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import java.io.IOException;

import static com.epam.sum_university.properties.Properties.*;

public class ProfileTest extends BaseTest {

    @AfterTest
    public void tearDown() {
        quit();
    }

    @Test
    public void ProfileTest() throws IOException {
        LoginPage loginPage = new LoginPage(webDriver);
        Boolean flag; AccountPage updateSucceed = loginPage
                .open()
                .login(LOGIN, PASS)
                        .openMyProfile().editFields(NAME,LAST_NAME,BIRTHDAY,ADDRESS,WEBSITE);
        updateSucceed.capture("profile");
        flag = updateSucceed.updateSucceed();

        Assert.assertTrue(flag);
    }
}
