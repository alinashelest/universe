package com.epam.sum_university.uitests.login;

import com.epam.sum_university.BaseTest;
import com.epam.sum_university.pageobject.pages.LoginPage;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import java.io.IOException;

import static com.epam.sum_university.properties.Properties.*;

public class LoginWithIncorrectPassword extends BaseTest {

    @AfterTest
    public void tearDown() {
        quit();
    }

    @Test
    public void negativeLoginTest() throws IOException {
        LoginPage loginPage = new LoginPage(webDriver);
        boolean flag; LoginPage errorLogin = loginPage
                .open()
                .negLoginIncorrectPassword(LOGIN,PASS1);
        errorLogin.capture("login/negative");
        flag = errorLogin.existErrorLoginIncorrectPassword();
        Assert.assertTrue(flag);
    }
}
